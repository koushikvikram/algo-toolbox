# Uses Python 3
import time

def gcd_naive(a, b):
    best = 0
    for d in range(1, a+b):
        if a%d==0 and b%d==0:
            best = d
    return best

def gcd_less_naive(a, b):
    d = min(a, b)
    for n in list(range(d+1))[::-1]:
        if (a%n==0 and b%n==0):
            return n

a, b = 22500000, 150000000

print("GCD Naive Start:", time.ctime())
print("gcd_naive -> GCD({}, {}) = {}".format(a, b, gcd_naive(a, b)))
print("GCD Naive End:", time.ctime())

print("GCD Less Naive Start:", time.ctime())
print("gcd_less_naive -> GCD({}, {}) = {}".format(a, b, gcd_less_naive(a, b)))
print("GCD Less Naive End:", time.ctime())