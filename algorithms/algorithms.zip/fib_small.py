# Good job! (Max time used: 0.02/5.00, max memory used: 9256960/536870912.
# Uses python3
def calc_fib(n):
    if n <= 1:
        return n

    fib_seq = [None] * (n + 1)
    fib_seq[0], fib_seq[1] = 0, 1

    for i in range(2, n + 1):
        fib_seq[i] = fib_seq[i - 1] + fib_seq[i - 2]
    return fib_seq[n]


n = int(input())
print(calc_fib(n))
