'''
Problem Statement:
"Find the maximum product of two distinct numbers in a sequence of non-negative integers."
Compute max(a_i, a_j) such that 1 <= i!=j <= n

Input: A sequence of non-negative integers
Input format: The first line contains an integer n. The next line contains n non-negative integers a_1, ..., a_n (separated by spaces)

Output: The maximum value that can be obtained by multiplying two different elements from the sequence
Output format: The maximum pairwise product

Eg.
Input:
3
1 2 3
Output:
6

Constraints: 2 <= n <= 2*10^5; 0 <= a_1, ..., a_n <= 2*10^5
'''

# Uses Python3
def mpp_naive(length, input_list):
    assert(length > 1 and length == len(input_list))

    product = 0
    for i in range(0, length):
        for j in range(1, length):
            if i != j:
                product = max(product, input_list[i]*input_list[j])
    return product

def mpp_fast(length, input_list):
    assert (length > 1 and length == len(input_list))

    index_1 = 0
    for i in range(1, length):
        if input_list[i] > input_list[index_1]:
            index_1 = i

    # index_2 = 0   # Failure case: input_list = [2,1], length = 2

    if index_1 == 0:
        index_2 = 1
    else:
        index_2 = 0

    for i in range(0, length):
        if i != index_1 and input_list[i] > input_list[index_2]:
            index_2 = i
    return input_list[index_1]*input_list[index_2]

def mpp_faster(length, input_list):
    assert(length > 1 and length == len(input_list))
    input_list.sort(reverse=True)
    return input_list[0]*input_list[1]

def mpp_faster_alternative(length, input_list):
    assert (length > 1 and length == len(input_list))
    largest = max(input_list)
    input_list.remove(largest)
    second_largest = max(input_list)
    return largest*second_largest

def mpp_reliable(length, input_list):
    assert (length > 1 and length == len(input_list))
    index = 0
    for i in range(1, length):
        if input_list[i] > input_list[index]:
            index = i
    input_list[index], input_list[-1] = input_list[-1], input_list[index]

    index = 0
    for i in range(1, length-1):
        if input_list[i] > input_list[index]:
            index = i
    input_list[index], input_list[-2] = input_list[-2], input_list[index]

    return input_list[-1]*input_list[-2]

def mpp_faulty(length, input_list):
    assert(length > 1)
    assert(length == len(input_list))

    product = 0

    for i in range(0, length):
        for j in range(1, length):
            product = max(product, input_list[i]*input_list[j])

    return product


def mpp_faulty_fast(length, input_list):
    assert (length > 1)
    assert(length == len(input_list))

    index_1 = 0
    for i in range(1, length):
        if input_list[i] > input_list[index_1]:
            index_1 = i

    # index_2 = 0   # Failure case: input_list = [2,1], length = 2

    if index_1 == 0:
        index_2 = 1
    else:
        index_2 = 0

    for i in range(0, length):
        if input_list[i] != input_list[index_1] and input_list[i] > input_list[index_2]:
            index_2 = i
    return input_list[index_1]*input_list[index_2]


input_list = [7, 5, 14, 2, 8, 8, 10, 1, 2, 3]
length = 10

# test case to catch faulty - expected result -> 16
# input_list = [1, 2, 3, 4, 4, 4]
# length = 6

print("Input:", input_list)
print("(Naive) Max pairwise product:", mpp_naive(length, input_list))
print("(Fast) Max pairwise product:", mpp_fast(length, input_list))
# print("(Faulty) Max pairwise product:", mpp_faulty(length, input_list))
# print("(Faulty Fast) Max pairwise product:", mpp_faulty_fast(length, input_list))

'''
Although the program states that the inputs are non-negative integers, let's see if our algorithms work on 
# Negative Integers
# Floating point values
'''

# Stress test with negative numbers or float or both
def stressTestMPP(max_length, max_number, naive_algorithm, fast_algorithm, negative=False, floating_point=False):
    ''' 4 parts of a stress test:
    1. Your implementation of an algorithm
    2. An alternative, trivial and slow, but correct implementation of an algorithm for the same problem
    3. A random test generator
    4. An infinite loop in which a nwe test is generated and fed into both implementations to compare the results.
       if the results differ:
            the test and both the answers are output and the program stops
       else:
            the program repeats'''
    import random
    while True:
        n = random.randint(2, max_length)
        input_list = []

        if negative:
            for i in range(n):
                input_list.append(random.randint(-max_number, max_number))
        elif floating_point:
            for i in range(n):
                input_list.append(random.uniform(0, max_number))
        elif negative and floating_point:
            for i in range(n):
                input_list.append(random.uniform(-max_number, max_number))
        else:
            for i in range(n):
                input_list.append(random.randint(0, max_number))

        print(input_list)
        result_1 = naive_algorithm(n, input_list)
        result_2 = fast_algorithm(n, input_list)
        if result_1 == result_2:
            print("OK")
        else:
            print("Wrong answer:", result_1, result_2)
            return

# Negative - All algorithms fail
# stressTestMPP(5, 9, mpp_naive, mpp_fast, negative=True)
# stressTestMPP(5, 9, mpp_naive, mpp_faster, negative=True)
# stressTestMPP(5, 9, mpp_naive, mpp_faster_alternative, negative=True)
# stressTestMPP(5, 9, mpp_naive, mpp_reliable, negative=True)

# Float - All algorithms succeed
# stressTestMPP(5, 9, mpp_naive, mpp_fast, floating_point=True)
# stressTestMPP(5, 9, mpp_naive, mpp_faster, floating_point=True)
# stressTestMPP(5, 9, mpp_naive, mpp_faster_alternative, floating_point=True)
# stressTestMPP(5, 9, mpp_naive, mpp_reliable, floating_point=True)

# Negative and Float - All algorithms fail
# stressTestMPP(5, 9, mpp_naive, mpp_fast, negative=True, floating_point=True)
# stressTestMPP(5, 9, mpp_naive, mpp_faster, negative=True, floating_point=True)
# stressTestMPP(5, 9, mpp_naive, mpp_faster_alternative, negative=True, floating_point=True)
# stressTestMPP(5, 9, mpp_naive, mpp_reliable, negative=True, floating_point=True)

# Positive Integers - Only positive integers - all algorithms succeed
# stressTestMPP(10, 100000, mpp_naive, mpp_fast)
# stressTestMPP(10, 100000, mpp_naive, mpp_faster)
# stressTestMPP(10, 100000, mpp_naive, mpp_faster_alternative)
# stressTestMPP(10, 100000, mpp_naive, mpp_reliable)

# stressTestMPP(5, 9, mpp_naive, mpp_fast)
# stressTestMPP(5, 9, mpp_naive, mpp_faster)
# stressTestMPP(5, 9, mpp_naive, mpp_faster_alternative)
# stressTestMPP(5, 9, mpp_naive, mpp_reliable)

# stressTestMPP(1000, 9000000, mpp_naive, mpp_fast)
# stressTestMPP(1000, 9000000, mpp_naive, mpp_faster)
# stressTestMPP(1000, 9000000, mpp_naive, mpp_faster_alternative)
# stressTestMPP(1000, 9000000, mpp_naive, mpp_reliable)